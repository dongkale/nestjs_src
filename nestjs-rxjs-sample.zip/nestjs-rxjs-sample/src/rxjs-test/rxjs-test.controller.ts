import { Controller, Get, Param } from '@nestjs/common';
import { RxjsTestService } from './rxjs-test.service';

import { EventSubscribeHandler } from '../event-subscribe/event-subscribe';

@Controller('rxjs-test')
export class RxjsTestController {
  constructor(
    private readonly service: RxjsTestService,
    private readonly eventSubscribeHandler: EventSubscribeHandler,
  ) {
    // const data = { name: 'none', number: 0 };

    // service.addedSubscribe('event1', (arg) => {
    //   console.log('event1 수신 : ', arg);
    // });

    // service.addedSubscribe('event2', (arg) => {
    //   console.log('event2 수신 : ', arg);
    // });

    // service.addedSubscribe('event3', (arg) => {
    //   console.log('event3 수신 : ', arg);
    // });

    // service.addedSubscribeEx('event1', (arg) => {
    //   console.log('EX: event1 수신 : ', arg);
    // });

    // service.addedSubscribeEx('event2', (arg) => {
    //   console.log('EX: event2 수신 : ', arg);
    // });

    // service.addedSubscribeEx('event3', (arg) => {
    //   console.log('EX: event3 수신 : ', arg);
    // });

    // service.addedEventSubscribe('event1', (event, arg) => {
    //   console.log(`[${event}] recved : ${JSON.stringify(arg)}}`);
    // });

    // service.addedEventSubscribe('event2', (event, arg) => {
    //   console.log(`[${event}] recved : ${JSON.stringify(arg)}}`);
    // });

    // service.addedEventSubscribe('event3', (event, arg) => {
    //   console.log(`=== ${this.service.getHello()}`);
    //   console.log(`[${event}] recved : ${JSON.stringify(arg)}}`);
    //   console.log(`=== ${arg.fn()}`);
    // });

    eventSubscribeHandler.addedEvent('event1', (event, arg) => {
      console.log(`[${event}] recved : ${JSON.stringify(arg)}}`);
    });

    eventSubscribeHandler.addedEvent('event2', (event, arg) => {
      console.log(`[${event}] recved : ${JSON.stringify(arg)}}`);
    });

    eventSubscribeHandler.addedEvent('event3', (event, arg) => {
      console.log(`=== ${this.service.getHello()}`);
      console.log(`[${event}] recved : ${JSON.stringify(arg, null, 2)}}`);
      console.log(`=== ${arg.fn()}`);
    });
  }

  @Get(':message')
  getHello(@Param('message') message: string): any {
    const data = { name: message, number: `id-${Date.now()}` };

    this.service.publishMessage('event1', data);

    return data; // this.appService.getHello();
  }

  @Get('event1/:message')
  getEvent1(@Param('message') message: string): any {
    const data = { name: message, number: `id-${Date.now()}`, event: 'event1' };

    // this.service.publishMessage('event1', data);
    // this.service.publishMessageEx('event1', data);
    // this.service.publishEventSubscribe('event1', data);

    this.eventSubscribeHandler.publishEvent('event1', data);

    return data; // this.appService.getHello();
  }

  @Get('event2/:message')
  getEvent2(@Param('message') message: string): any {
    const data = { name: message, number: `id-${Date.now()}`, event: 'event2' };

    // this.service.publishMessage('event2', data);
    // this.service.publishMessageEx('event2', data);
    // this.service.publishEventSubscribe('event2', data);

    this.eventSubscribeHandler.publishEvent('event2', data);

    return data; // this.appService.getHello();
  }

  @Get('event3/:message')
  getEvent3(@Param('message') message: string): any {
    const data = {
      name: message,
      number: `id-${Date.now()}`,
      event: 'event3',
      fn: this.service.getHello,
    };

    // this.service.publishMessage('event3', data);
    // this.service.publishMessageEx('event3', data);
    // this.service.publishEventSubscribe('event3', data);

    this.eventSubscribeHandler.publishEvent('event3', data);

    return data; // this.appService.getHello();
  }
}
