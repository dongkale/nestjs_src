export class OrderCreatedEvent {
  name: string;
  description: string;
}
