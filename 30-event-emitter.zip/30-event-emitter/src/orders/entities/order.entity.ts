export class Order {
  id: number;
  name: string;
  description: string;
}
