export class CreateOrderDto {
  name: string;
  description: string;
}
